import Foundation

//1. Описать класс Car c общими свойствами автомобилей и пустым методом действия по аналогии с прошлым заданием.
//2. Описать пару его наследников trunkCar и sportСar. Подумать, какими отличительными свойствами обладают эти автомобили. Описать в каждом наследнике специфичные для него свойства.
//3. Взять из прошлого урока enum с действиями над автомобилем. Подумать, какие особенные действия имеет trunkCar, а какие – sportCar. Добавить эти действия в перечисление.
//4. В каждом подклассе переопределить метод действия с автомобилем в соответствии с его классом.
//5. Создать несколько объектов каждого класса. Применить к ним различные действия.
//6. Вывести значения свойств экземпляров в консоль.


class Car {
    let mark: String
    let year: Int
    let trunkVolume: Double
    var engineIsRunning: Bool
    var windowsAreOpen: Bool

    enum Action {
        case startEngine
        case stopEngine
        case openWindows
        case closeWindows
    }
    
    init(mark: String, year: Int, trunkVolume: Double, engineIsRunning: Bool, windowsAreOpen: Bool) {
        self.mark = mark
        self.year = year
        self.trunkVolume = trunkVolume
        self.engineIsRunning = engineIsRunning
        self.windowsAreOpen = windowsAreOpen
        
    }
    
    func doSomething(action: Action) {
        switch action {
        case .startEngine:
            engineIsRunning = true
            print("Двигатель запущен")
        case .stopEngine:
            engineIsRunning = false
            print("Двигатель заглушен")
        case .openWindows:
            windowsAreOpen = true
            print("Окна открыты")
        case .closeWindows:
            windowsAreOpen = false
            print("Окна закрыты")
      
        }
    }
    func printInfo() {
        print("----------------------")
        print("Марка авто: \(self.mark)")
        print("Объем багажника: \(self.trunkVolume) м3")
        print("Состояние двигателя: \(self.engineIsRunning ? "Запущен" : "Заглушен")")
        print("Окна: \(self.windowsAreOpen ? "Открыты" : "Закрыты")")
    }
}

enum HatchState: String {
    case hatchIsOpen = "Открыт"
    case hatchIsClosed = "Закрыт"
}

class SportСar: Car {
    
    var hatchState: HatchState
    var spoiler: Bool
    
    init(mark: String, year: Int, trunkVolume: Double, engineIsRunning: Bool, windowsAreOpen: Bool, hatchState: HatchState, spoiler: Bool) {
        self.hatchState = hatchState
        self.spoiler = spoiler
        super.init(mark: mark, year: year, trunkVolume: trunkVolume, engineIsRunning: engineIsRunning, windowsAreOpen: windowsAreOpen)
    }
   
    func openHatch() {
        self.hatchState = .hatchIsOpen
        print("Действие: люк открыт")
    }

    func closeHatch()  {
        self.hatchState = .hatchIsClosed
        print("Действие: люк закрыт")
    }

    func addSpoiler() {
        if self.spoiler == false {
            self.spoiler == true
            print("Добавили спойлер")
        }; if self.spoiler == true {
            print("Cпойлер уже установлен")
        }
    }

    func removeSpoiler() {
        if self.spoiler == true {
            self.spoiler == false
            print("Убрали спойлер")
        }; if self.spoiler == false {
            print("Cпойлера ещё нет")
        }
    }
//    override func doSomething(action: Car.Action) {
//        super.doSomething(action: .startEngine)
//        super.doSomething(action: .stopEngine)    // Можно ли как-то объединить эти super
//        super.doSomething(action: .openWindows)   // или же лучше каждую фукцию отдельно прописывать изначально?
//        super.doSomething(action: .closeWindows)
//        switch action {
//        case HatchState.open:                     // Как здесь правильно switch оформить? Я видимо совсем запупался
//                print("Действие: люк открыт")
//        case HatchState.close:
//                print("Действие: люк закрыт")
//        }
//    }
    
    override func printInfo() {
        super.printInfo()
        print("Люк: \(self.hatchState.rawValue)")
        print("Наличие спойлера: \(self.spoiler ? "Присутствует" : "Отсутствует")")
    }
}

var fastCar = SportСar(mark: "Subaru", year: 2019, trunkVolume: 10, engineIsRunning: false, windowsAreOpen: true, hatchState: .hatchIsOpen, spoiler: false)

fastCar.printInfo()
fastCar.doSomething(action: .startEngine)
fastCar.doSomething(action: .closeWindows)
fastCar.closeHatch()
fastCar.addSpoiler()




class TrunkCar: Car {
    var autoLoader: Bool
    var spareWheels: Bool
    
    init(mark: String, year: Int, trunkVolume: Double, engineIsRunning: Bool, windowsAreOpen: Bool, autoLoader: Bool, spareWheels: Bool) {
        self.autoLoader = autoLoader
        self.spareWheels = spareWheels
        super.init(mark: mark, year: year, trunkVolume: trunkVolume, engineIsRunning: engineIsRunning, windowsAreOpen: windowsAreOpen)
    }
    
    func setWheels() {
        self.spareWheels == true
        print("Запасные колеса подготовлены")
    }
    
    func removeWheels() {
        self.spareWheels == false
        print("Запасные колеса сняты")
    }
    
    override func printInfo() {
        super.printInfo()
        print("Автопогрузчик: \(self.autoLoader ? "Присутствует" : "Отсутствует")")
        print("Наличие запасных колес: \(self.spareWheels ? "Присутствуют" : "Отсутствуют")")
    }
    
}

var truckTruckTruck = TrunkCar(mark: "KAMAZ", year: 2015, trunkVolume: 100, engineIsRunning: false, windowsAreOpen: false, autoLoader: true, spareWheels: false)

truckTruckTruck.printInfo()
truckTruckTruck.doSomething(action: .openWindows)
truckTruckTruck.setWheels()
